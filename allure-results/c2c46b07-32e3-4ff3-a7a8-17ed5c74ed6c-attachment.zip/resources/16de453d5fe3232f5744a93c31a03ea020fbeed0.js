/*
This Setandsubmit method used to edit the value of a specific field.
The user should be aware of the field name that needs to be changed.
To find the field name, the user should use console.log(window.fields) and check for the field name that needs to be changed.
The user should set window.operation (e.g.,window.operation = "I" OR "VAL") to trigger actions like Commit/Validate.
*/
/*
function Setandsubmit(fieldname,fieldValue,action) {
  try {
    let fields = window?.fields;
    for (const fld of fields) {
      if (fld.fieldName === fieldname) {
        fld.value = fieldValue;
        fld.hasChanged = true;
        window.operation = action;
      }
    }
  } catch (error) {
    console.error('Error:', error.message);
  }
  return;
}
*/
/*
 * validateDropdown — optional hook to block dropdown lookups before they fire.
 *
 * Receives:
 *   appOrTableId  — the application/table identifier for the dropdown field
 *   fieldValue    — the current value typed in the field (empty string / undefined when blank)
 *
 * Return false  → cancel the dropdown request (show your own message to the user).
 * Return nothing (undefined) → allow the request to proceed as normal.
 *
 * Uncomment and customise the sample below to enable this behaviour.
 */

// window.validateDropdown = function (appOrTableId, fieldValue) {
//   var BLOCKED_APPS = ['CUSTOMER', 'ACCOUNT']; // add application IDs to block without criteria
//   if (BLOCKED_APPS.indexOf(appOrTableId) !== -1 && !fieldValue) {
//     alert('Please enter search criteria before performing a lookup.');
//     return false;
//   }
// };

/*
* Sample JavaScript method.
* 
* This method can be attached with any application/version screens using BROWSER.TOOLS/TOOLBAR application.
* "window.recordId" stores transaction-id of the object in the current screen
* "window.screen" stores requirement information of the current screen.
* "transactExplorerLib.getQueryResults(command)" can be used to get enquiry response for any command-line argument. 
* "transactExplorerLib.getScreenResponse(command)" can be used to get version response for any command-line argument. 
*/
/*
async function <JavaScriptMethod>()
{
    resp = await transactExplorerLib.getQueryResults("ENQ CUSTOMER @ID EQ "+ window.screen.key);
    alert((resp[0].body.query.dataSection.enqResponse?.enqDesc)  +" enquiry has been called");
    resp = await transactExplorerLib.getScreenResponse("CUSTOMER S 100100");
    alert(resp[0].body.contract.app + " " + resp[0].body.screenMode + " " + resp[0].body.contract.key   +" command is launched");
}
*/

/*
* Sample JavaScript method.
* 
* This method can be attached with any application/version screens using BROWSER.TOOLS/TOOLBAR application.
* "window.recordId" stores transaction-id of the object in the current screen
* "window.screen" stores requirement information of the current screen.
* "window.screen.app" stores application-id of the current screen.
* "window.screen.version" stores version-id of the current screen.
* "transactExplorerLib.runCommand (command, target)" can be used to launch any command-line argument. 
*         - This runCommand method will launch the screen in a new tab.
*         - It accepts two arguments. command is the command-line text. target can be set to self to launch the screen in same tab.
*/
/*
function <JavaScriptMethod>()
{
	//Fetch screen details
	var transId  = window.recordId;
	var appValue = window.screen.app;
	var verValue  = window.screen.version;
	//Frame commands
	cmdDetails = "TAB CUSTOMER.DETAILS '" + transId +"'";
	if (verValue == "") {
		cmdDetails = "TAB TXN.HIST.VIEW.TAB.MB 2 APPLICATION EQ " + appValue + " REC.ID EQ " + transId
	} else {
		cmdDetails = "TAB TXN.HIST.VIEW.TAB.MB APPLICATION EQ " + appValue + verValue +" REC.ID EQ " + transId
	}
 

	//launch screen in a new tab
	transactExplorerLib.runCommand(cmdDetails);
}
*/

/* This function defines a set of utility functions under the object `TemenosTemplateFunctions`
 1. genCurrentDDMMYYYY: Generates the current date in the format 'DD/MM/YYYY'.
    - Returns the formatted date as a string (e.g., '25/11/2024').

 2. getRowColVal: Retrieves a value based on a row and column identifier (e.g., 'R1C2') from a parent window object.
    - It extracts the column number from the argument (in the format 'RC<column number>') and tries to access the 
      corresponding value in the parent window's `rowObject` using the column number.

Note : Comment the return function and uncomment the other line to code to get the expected values. */

var TemenosTemplateFunctions = (function () {
  function genCurrentDDMMYYYY() {
    return;
    // const date = new Date(),
    //   dayOfMonth = date.getDate(),
    //   monthNumber = date.getMonth() + 1;
    // return [
    //   dayOfMonth < 10 ? '0' : '',
    //   dayOfMonth,
    //   '/',
    //   monthNumber < 10 ? '0' : '',
    //   monthNumber,
    //   '/',
    //   date.getFullYear(),
    // ].join('');
  }

  function getRowColVal(rc_arg) {
    return;
    // let rowValue;
    // try {
    //   let colNum = rc_arg.split('C')[1].slice(0, -1);
    //   rowValue = window.parent.rowObject[colNum]?.cap;
    // } catch {
    //   console.warn('Error in getRowColVal.js file');
    // }
    // return rowValue;
  }
  /* 
  * This function retrieves the value of a deeply nested property within an object 
  based on a dot-separated string path (e.g., "query.dataSection.enqResponse.title").
  * It traverses the object step by step, checking if each property exists. 
  * If any part of the path is invalid, it returns undefined and logs a warning.
*/
  function getResData(rc_arg) {
    return;
    // let rowValue;
    // const keys = rc_arg.split('.');

    // try {
    //   let currentObj = window.top.transactExplorerLib.styleSheetResponse;

    //   for (let key of keys) {
    //     if (currentObj && currentObj.hasOwnProperty(key)) {
    //       currentObj = currentObj[key];
    //     } else {
    //       console.warn(`Property does not exist in the object path.`);
    //       return undefined;
    //     }
    //   }
    //   rowValue = currentObj;
    // } catch (error) {
    //   console.warn('Error accessing the property path in getResData:', error);
    // }

    // return rowValue;
  }
  /*function to print inner html from the deal slipresponse*/
  function printInnerHtml() {
    return;
    // document.getElementById('printResponseHtmlId').innerHTML = getResData('query.dataSection.enqResponse.r.c.rpt.sp');
  }
  return {
    genCurrentDDMMYYYY: genCurrentDDMMYYYY,
    getRowColVal: getRowColVal,
    getResData: getResData,
    printInnerHtml: printInnerHtml,
  };
})();

/*
* Sample JavaScript method.
* 
* This method can be used to call http methods GET,PUT,POST and DELETE
* url -  http url fo calling API
* Methods :
*       httpGet - http.get can be called using transactExplorerLib.httpGet(url, headers)
*       httpPut - http.put can be called using transactExplorerLib.httpPut(url, request, headers)
*       httpPost - http.post can be called using transactExplorerLib.httpPost(url, request, headers)
*       httpDelete - http.delete can be called using transactExplorerLib.httpDelete(url, request)
*/
/*
async function <JavaScriptMethod>()
{
  const headers = {
  headers:{
    'Access-Control-Allow-Origin': '*',
  }
}
  const url =  'http://localhost:9089/irf-provider-container/api/v1.0.0/party/customers/';
  const getResponse = await transactExplorerLib.httpGet(url , headers);
  if(getResponse)
  console.log("Get response" + JSON.stringify(getResponse));

  const puturl = 'http://localhost:9089/irf-provider-container/api/v1.0.0/party/customers/66052';
  const request =
  {
    "override": {
        "overrideDetails": [
            {
                "code": "O-12005",
                "options": [
                    "RECEIVED",
                    "NOT RECEIVED"
                ],
                "description": "Have you received Business License or Incorportn Cert/CUS*200 from 66052}RECEIVED_NOT RECEIVED",
                "id": "DM.CONFIRM.DOC",
                "type": "Warning"
            },
            {
                "code": "O-12005",
                "options": [
                    "RECEIVED",
                    "NOT RECEIVED"
                ],
                "description": "Have you received Memorandum and Articles of Asscn/CUS*200 from 66052}RECEIVED_NOT RECEIVED",
                "id": "DM.CONFIRM.DOC",
                "type": "Warning"
            }
        ]
    },
    "body": {
        "sectorId": 1001
    }
  }
  const putResponse = await transactExplorerLib.httpPut(puturl , request , headers);
  if(putResponse)
  console.log("updated response " + JSON.stringify(putResponse[0]?.body?.sectorId))

  const posturl = 'http://localhost:9089/irf-provider-container/api/v1.0.0/party/customers/';
  const postRequest =
    {
      "body": {
          "customerMnemonic": "NOKIATESL",
          "sectorId": 1002,
          "addresses": [
              {
                  "address": "94086 SUNNYVALE"
              }
          ],
          "streets": [
              {
                  "street": "200 SOUTH MATIDLA AVENUE"
              }
          ],
          "nationalityId": "US",
          "addressCities": [
              {
                  "addressCity": "CALIFORNIA"
              }
          ],
          "displayNames": [
              {
                  "displayName": "NOKIA US"
              }
          ],
          "customerNames": [
              {
                  "customerName": "NOKIA US"
              }
          ],
          "language": 1,
          "amlCheck": "NULL",
          "residenceId": "US",
          "target": 7,
          "customerStatus": 1,
          "industryId": 2850,
          "accountOfficerId": 2002,
          "birthIncorpDate": "1867-06-07",
          "customerCompany": "GB0010001",
          "amlResult": "NULL"
      }
  }
  const postResponse = await transactExplorerLib.httpPost(posturl , postRequest , headers);
  if(postResponse)
  console.log(postResponse[0]?.header?.id +" is successfully created")

  const deleteUrl =  'http://localhost:9089/irf-provider-container/api/v1.0.1/party/externalUserRequests/IB2510583380';
  const deleteResponse = await transactExplorerLib.httpDelete(deleteUrl , headers);
  if(deleteResponse)
  console.log(deleteResponse[0]?.header?.id +" is successfully deleted");
}
*/
/*
 * Sample JavaScript method.
 *
 * This method can be used to set attribute for enquiries.
 * "window.screen" stores information of the current screen.
 * "transactExplorerLib.runCommand (command, target , EnquiryArguments)" can be used to launch any command-line argument.
 *         - This runCommand method will launch the command in the screen.
 *         - It accepts three arguments.
 *           Command - cmd line argument
 *           target  -
 *                   target can be set as blank to open in new tab
 *                   target can be set as currentpage to launch the screen in same tab.
 *                   target can be set as currentframe to refresh screen data alone of enquiry page.
 *           enqArgs - set the required enquiry arguments
 *                   ALLDATA can be set to true when all data to be displayed for enquiry
 *  Enquiryselection Tag meanings:
 *  <n> – Field Name (internal name / system code)
 *  <c> – Field Caption (display name)
 *  <op> – Operator
 *  <d> – Data / Value
 *  <m> – Mandatory flag
 *  <i> – Index / Order
 */

/*
function <JavaScriptMethod>()
{
const enqArgs = { 
    ALLDATA : true,
    windowId: window?.windowId
  };

  let formatSelection;
  const data = window?.screen?.dataSection?.enqResponse;
  const selection = window?.screen?.selSection?.selDets?.enqsel.f || window.selections;
  if(selection) {
    if (selection.length > 1) {
      cmdDetails = "ENQ " + (data?.enqid || window?.screen);
      formatSelection = true;
    } else {
      let value = selection?.d ?? selection?.[0]?.data;
      const parts = value?.split(" ");
      if (parts?.length > 1) {
        value = `'${parts.join(" ")}'`;
      }
      cmdDetails = "ENQ " + (data?.enqid || window?.screen) + ' ' + (selection?.n ?? selection?.c ?? selection?.[0]?.field ?? selection?.[0]?.name) + ' '+ (selection?.op ?? selection?.[0]?.operand) + ' '+ value;
    }
  } else if (window.arguments) {
    cmdDetails = "ENQ " + (data?.enqid || window?.screen) + ' ' + window.arguments;
  }
  else
  {
	cmdDetails = "ENQ " + (data?.enqid || window?.screen) ;
  }
	transactExplorerLib.runCommand(cmdDetails , "currentframe" , enqArgs, formatSelection, selection);
}
*/
